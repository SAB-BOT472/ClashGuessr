CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  total_wins INTEGER DEFAULT 0,
  best_endless INTEGER DEFAULT 0,
  guesses_made INTEGER DEFAULT 0,
  pixel_wins INTEGER DEFAULT 0,
  best_pixel INTEGER DEFAULT 0,
  pixel_guesses INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);
