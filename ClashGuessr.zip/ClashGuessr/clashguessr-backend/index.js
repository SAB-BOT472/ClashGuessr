require('dotenv').config();
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const { Pool } = require('pg');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'change-this';
const COOKIE_NAME = process.env.COOKIE_NAME || 'cg_token';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSLMODE === 'require' ? { rejectUnauthorized: false } : false
});

// Middlewares
app.use(express.json());
// Allow requests from your frontend origin (set in env)
app.use(cors({
  origin: process.env.FRONTEND_ORIGIN || 'http://localhost:5500',
  credentials: true
}));
app.use(cookieParser());

// Utility: verify token middleware
function authMiddleware(req, res, next){
  const token = req.cookies[COOKIE_NAME] || (req.header('Authorization') && req.header('Authorization').split(' ')[1]);
  if(!token) return res.status(401).json({ error: 'unauthenticated' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'invalid token' });
  }
}

// API: signup
app.post('/api/signup', async (req, res) => {
  const { username, password } = req.body;
  if(!username || !password) return res.status(400).json({ error: 'username & password required' });
  const client = await pool.connect();
  try {
    // check existing
    const { rows } = await client.query('SELECT id FROM users WHERE username = $1', [username]);
    if(rows.length) return res.status(409).json({ error: 'username_taken' });
    const hashed = await bcrypt.hash(password, 12);
    const insert = await client.query(
      `INSERT INTO users (username, password_hash, total_wins, best_endless, guesses_made, pixel_wins, best_pixel, pixel_guesses, created_at)
       VALUES ($1,$2,0,0,0,0,0,0,NOW()) RETURNING id, username`,
      [username, hashed]
    );
    const user = insert.rows[0];
    // create token
    const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '30d' });
    // set cookie httpOnly
    res.cookie(COOKIE_NAME, token, { httpOnly: true, secure: process.env.COOKIE_SECURE === 'true', maxAge: 30*24*3600*1000 });
    res.json({ ok: true, user: { id: user.id, username: user.username } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'server_error' });
  } finally {
    client.release();
  }
});

// API: login
app.post('/api/login', async (req, res) => {
  const { username, password, remember } = req.body;
  if(!username || !password) return res.status(400).json({ error: 'username & password required' });
  const client = await pool.connect();
  try {
    const { rows } = await client.query('SELECT id, username, password_hash FROM users WHERE username = $1', [username]);
    if(!rows.length) return res.status(401).json({ error: 'invalid_credentials' });
    const u = rows[0];
    const ok = await bcrypt.compare(password, u.password_hash);
    if(!ok) return res.status(401).json({ error: 'invalid_credentials' });
    const token = jwt.sign({ id: u.id, username: u.username }, JWT_SECRET, { expiresIn: remember ? '30d' : '8h' });
    res.cookie(COOKIE_NAME, token, { httpOnly: true, secure: process.env.COOKIE_SECURE === 'true', maxAge: remember ? 30*24*3600*1000 : 8*3600*1000 });
    res.json({ ok: true, user: { id: u.id, username: u.username } });
  } catch(e){
    console.error(e);
    res.status(500).json({ error: 'server_error' });
  } finally { client.release(); }
});

// API: logout
app.post('/api/logout', (req,res)=>{
  res.clearCookie(COOKIE_NAME);
  res.json({ ok: true });
});

// API: get current user (me)
app.get('/api/me', authMiddleware, async (req, res) => {
  const client = await pool.connect();
  try {
    const { rows } = await client.query('SELECT id, username, total_wins, best_endless, guesses_made, pixel_wins, best_pixel, pixel_guesses FROM users WHERE id = $1', [req.user.id]);
    if(!rows.length) return res.status(404).json({ error: 'not_found' });
    res.json({ ok: true, user: rows[0] });
  } catch(e){ console.error(e); res.status(500).json({ error:'server_error' }); } finally { client.release(); }
});

// API: leaderboard (top N)
app.get('/api/leaderboard', async (req, res) => {
  const limit = Math.min(100, parseInt(req.query.limit || '20', 10));
  const client = await pool.connect();
  try {
    const { rows } = await client.query('SELECT username, total_wins, best_endless FROM users ORDER BY total_wins DESC, best_endless DESC LIMIT $1', [limit]);
    res.json({ ok: true, list: rows });
  } catch(e){ console.error(e); res.status(500).json({ error:'server_error' }); } finally { client.release(); }
});

// API: update stats (called when user wins or guesses)
app.post('/api/update-stats', authMiddleware, async (req, res) => {
  // body: { win: boolean, endlessScore: number|null, pixel: boolean (optional) }
  const { win, endlessScore, pixel } = req.body;
  const client = await pool.connect();
  try {
    if(pixel){
      // update pixel stats
      if(win){
        await client.query('UPDATE users SET pixel_wins = COALESCE(pixel_wins,0) + 1 WHERE id = $1', [req.user.id]);
      }
      if(typeof endlessScore === 'number'){
        await client.query('UPDATE users SET best_pixel = GREATEST(COALESCE(best_pixel,0), $2) WHERE id = $1', [req.user.id, endlessScore]);
      }
      await client.query('UPDATE users SET pixel_guesses = COALESCE(pixel_guesses,0) + 1 WHERE id = $1', [req.user.id]);
    } else {
      if(win){
        await client.query('UPDATE users SET total_wins = COALESCE(total_wins,0) + 1 WHERE id = $1', [req.user.id]);
      }
      if(typeof endlessScore === 'number'){
        await client.query('UPDATE users SET best_endless = GREATEST(COALESCE(best_endless,0), $2) WHERE id = $1', [req.user.id, endlessScore]);
      }
      await client.query('UPDATE users SET guesses_made = COALESCE(guesses_made,0) + 1 WHERE id = $1', [req.user.id]);
    }
    res.json({ ok: true });
  } catch(e){ console.error(e); res.status(500).json({ error:'server_error' }); } finally { client.release(); }
});

// Health
app.get('/api/health', (req,res)=>res.json({ ok:true }));

// Start
app.listen(PORT, ()=> console.log(`Server listening on ${PORT}`));
